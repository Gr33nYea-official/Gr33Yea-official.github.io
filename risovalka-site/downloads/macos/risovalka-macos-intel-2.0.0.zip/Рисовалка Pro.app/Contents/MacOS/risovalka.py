#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageTk
import os
import platform
import json
from datetime import datetime

class DrawingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Рисовалка Pro")
        self.root.geometry("1000x700")
        
        self.pen_color = "#000000"
        self.pen_size = 3
        self.eraser_on = False
        self.last_x = None
        self.last_y = None
        self.current_tool = "pen"
        
        self.themes = {
            "light": {
                "bg": "#f0f0f0",
                "fg": "#000000",
                "canvas_bg": "#ffffff",
                "button_bg": "#e0e0e0",
                "button_fg": "#000000",
                "accent": "#4CAF50"
            },
            "dark": {
                "bg": "#1e1e1e",
                "fg": "#ffffff",
                "canvas_bg": "#1e1e1e",
                "button_bg": "#4a4a4a",
                "button_fg": "#ffffff",
                "accent": "#2e7d32"
            }
        }
        self.current_theme = "light"
        
        self.setup_ui()
        self.setup_canvas()
        self.setup_bindings()
        self.apply_theme()
    
    def setup_ui(self):
        toolbar = tk.Frame(self.root, height=50)
        toolbar.pack(side=tk.TOP, fill=tk.X)
        toolbar.pack_propagate(False)
        
        self.pen_btn = tk.Button(toolbar, text="✏️ Карандаш", command=self.use_pen)
        self.pen_btn.pack(side=tk.LEFT, padx=2, pady=10)
        
        self.eraser_btn = tk.Button(toolbar, text="🧽 Ластик", command=self.use_eraser)
        self.eraser_btn.pack(side=tk.LEFT, padx=2, pady=10)
        
        tk.Label(toolbar, text="Цвет:").pack(side=tk.LEFT, padx=10)
        self.color_btn = tk.Button(toolbar, bg=self.pen_color, width=3, height=1, command=self.choose_color)
        self.color_btn.pack(side=tk.LEFT, padx=2)
        
        tk.Label(toolbar, text="Размер:").pack(side=tk.LEFT, padx=10)
        self.size_scale = tk.Scale(toolbar, from_=1, to=20, orient=tk.HORIZONTAL, length=150, command=self.change_size)
        self.size_scale.set(3)
        self.size_scale.pack(side=tk.LEFT, padx=5)
        
        self.theme_btn = tk.Button(toolbar, text="🌙 Темная", command=self.toggle_theme)
        self.theme_btn.pack(side=tk.RIGHT, padx=10)
        
        tk.Button(toolbar, text="💾 Сохранить", command=self.save_image, bg="#4CAF50", fg="white").pack(side=tk.RIGHT, padx=5)
        
        self.status_bar = tk.Label(self.root, text="Готов к рисованию", anchor=tk.W, padx=10)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
    
    def setup_canvas(self):
        container = tk.Frame(self.root)
        container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.canvas = tk.Canvas(container, cursor="cross")
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        self.image = Image.new("RGB", (1000, 700), "white")
        self.draw = ImageDraw.Draw(self.image)
    
    def setup_bindings(self):
        self.canvas.bind("<Button-1>", self.start_draw)
        self.canvas.bind("<B1-Motion>", self.draw_line)
        self.canvas.bind("<ButtonRelease-1>", self.stop_draw)
    
    def start_draw(self, event):
        self.last_x = event.x
        self.last_y = event.y
    
    def draw_line(self, event):
        if self.last_x and self.last_y:
            color = "white" if self.eraser_on else self.pen_color
            self.canvas.create_line(self.last_x, self.last_y, event.x, event.y,
                                   fill=color, width=self.pen_size, capstyle=tk.ROUND, smooth=True)
            self.draw.line([self.last_x, self.last_y, event.x, event.y], fill=color, width=self.pen_size)
        self.last_x = event.x
        self.last_y = event.y
    
    def stop_draw(self, event):
        self.last_x = None
        self.last_y = None
    
    def use_pen(self):
        self.eraser_on = False
        self.current_tool = "pen"
        self.pen_btn.config(relief=tk.SUNKEN)
        self.eraser_btn.config(relief=tk.RAISED)
    
    def use_eraser(self):
        self.eraser_on = True
        self.current_tool = "eraser"
        self.eraser_btn.config(relief=tk.SUNKEN)
        self.pen_btn.config(relief=tk.RAISED)
    
    def choose_color(self):
        color = colorchooser.askcolor(title="Выберите цвет")
        if color[1]:
            self.pen_color = color[1]
            self.color_btn.config(bg=self.pen_color)
    
    def change_size(self, value):
        self.pen_size = int(value)
    
    def toggle_theme(self):
        self.current_theme = "dark" if self.current_theme == "light" else "light"
        self.apply_theme()
    
    def apply_theme(self):
        theme = self.themes[self.current_theme]
        self.root.configure(bg=theme["bg"])
        self.canvas.configure(bg=theme["canvas_bg"])
        self.status_bar.configure(bg=theme["bg"], fg=theme["fg"])
        self.pen_btn.configure(bg=theme["button_bg"], fg=theme["button_fg"])
        self.eraser_btn.configure(bg=theme["button_bg"], fg=theme["button_fg"])
        self.theme_btn.configure(bg=theme["button_bg"], fg=theme["button_fg"])
        self.theme_btn.config(text="☀️ Светлая" if self.current_theme == "dark" else "🌙 Темная")
    
    def save_image(self):
        file_path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[
                ("PNG files", "*.png"),
                ("JPEG files", "*.jpg"),
                ("BMP files", "*.bmp"),
                ("All files", "*.*")
            ]
        )
        if file_path:
            try:
                self.image.save(file_path)
                self.status_bar.config(text=f"Сохранено: {os.path.basename(file_path)}")
                messagebox.showinfo("Успех", "Изображение сохранено!")
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось сохранить: {e}")

def main():
    root = tk.Tk()
    app = DrawingApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
