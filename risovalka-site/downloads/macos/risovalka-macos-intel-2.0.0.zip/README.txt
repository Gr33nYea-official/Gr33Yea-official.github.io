=== Рисовалка Pro для macOS ===
Версия: 2.0.0

Установка:
1. Установите Python с python.org
2. Установите Pillow: pip3 install Pillow
3. Запустите start.command

Поддержка: https://www.donationalerts.com/r/gr33nyea_the_builder
