#!/bin/bash
python3 risovalka.py
