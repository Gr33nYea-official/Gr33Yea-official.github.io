=== Рисовалка Pro для Linux ===
Версия: 2.0.0

Установка:
1. Установите Python: sudo apt install python3
2. Установите Pillow: pip3 install Pillow
3. Запустите: ./start.sh

Поддержка: https://www.donationalerts.com/r/gr33nyea_the_builder
