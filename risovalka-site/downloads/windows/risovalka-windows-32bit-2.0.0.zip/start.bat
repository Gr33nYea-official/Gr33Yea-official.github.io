@echo off
echo Запуск Рисовалки Pro...
python risovalka.py
pause
