=== Рисовалка Pro для Windows ===
Версия: 2.0.0

Установка:
1. Установите Python с python.org
2. Установите Pillow: pip install Pillow
3. Запустите start.bat

Поддержка: https://www.donationalerts.com/r/gr33nyea_the_builder
