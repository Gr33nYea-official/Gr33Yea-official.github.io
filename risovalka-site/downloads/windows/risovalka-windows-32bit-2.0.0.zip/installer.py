#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import messagebox, ttk, scrolledtext
import os
import sys
import platform
import subprocess
import threading
import webbrowser

class RisovalkaInstaller:
    def __init__(self, root):
        self.root = root
        self.root.title("Рисовалка Pro - Установщик")
        self.root.geometry("600x400")
        
        self.os_name = platform.system()
        
        tk.Label(root, text="🎨 Рисовалка Pro", font=("Arial", 24, "bold")).pack(pady=20)
        tk.Label(root, text=f"Установка для {self.os_name}", font=("Arial", 14)).pack()
        
        tk.Button(root, text="Установить приложение", 
                 command=self.install, bg="#4CAF50", fg="white",
                 font=("Arial", 12), padx=20, pady=10).pack(pady=20)
        
        self.status = tk.Label(root, text="Готов к установке")
        self.status.pack()
    
    def install(self):
        self.status.config(text="Установка...")
        
        # Создаем папку на рабочем столе
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        app_dir = os.path.join(desktop, "Рисовалка Pro")
        
        if not os.path.exists(app_dir):
            os.makedirs(app_dir)
        
        # Здесь будет копирование файлов
        messagebox.showinfo("Успех", f"Приложение установлено в:
{app_dir}")
        self.status.config(text="Установка завершена")

def main():
    root = tk.Tk()
    app = RisovalkaInstaller(root)
    root.mainloop()

if __name__ == "__main__":
    main()
