@echo off
echo Установка Рисовалки Pro...
python installer.py
pause
